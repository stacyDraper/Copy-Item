# CHANGELOG (Test proposal) — 20250908-194534 UTC

- Add small v1.1 demo notes to:
  - docs/08-json-contracts.md
  - docs/17-stage-1-input-validation.md
- This is a non-breaking addendum for pipeline verification.
