# CHANGELOG (Proposals-only) — 20250909-004035 UTC

- Add small v1.1 demo notes to:
  - docs/08-json-contracts.md
  - docs/17-stage-1-input-validation.md
